from distutils.core import setup

setup(name='ReatArea',
      version='1.0',
      py_modules=['Event','Facility','Food','gasStation','gmail','mainloop','mysmtplib','noti','RestArea','telegram','test','FacillityTest'],
      packages={'resource':'_mk'}
      )