from distutils.core import setup

setup(name='ReatArea',
      version='1.0',
      py_modules=['Event','Facility','Food','gasStation','gmail','mainloop','mysmtplib','noti','RestArea','telegram','test','FacillityTest'],
      data_files={'resource\_01.jpg', 'resource\_02.jpg', 'resource\_03.jpg', 'resource\_04.jpg', 'resource\_05.jpg', 'resource\_06.jpg', '____.png', '__finfin.png', 'resource\_bg.png',
                  'resource\_bjw.jpg', 'resource\_hju.jpg', 'resource\_hn.jpg', 'resource\_hs.jpg', 'resource\_mk.jpg'
                  , 'resource\_moya.png', 'resource\_newMail.png', 'resource\_no.png', 'resource\logolego.PNG', 'resource\logolegoA.gif',
                  'resource\logolegoApng.png', 'resource\mail.gif', 'resource\R.gif', 'resource\RA.gif'}
      )



# from distutils.core import setup, Extension
# setup(name='WarmHeart',
# version='1.0',
# py_modules=['gmail', 'mysmtplib', 'noti','OpenApiParsing','OpenSidoApi','OpenSigunguApi','teller','tkinterGUI'],
# data_files=['Image\EmptyHeartButton.png','Image\GraphButton.png','Image\ImageButton.png','Image\MailButton.png','Image\RedHeartButton.png','Image\WarmHeartLogo.png']
# )