# 얘가 메인루프 이걸 실행시키면 됩니다
import RestArea

restArea = RestArea.RestArea()
restArea.window.mainloop()